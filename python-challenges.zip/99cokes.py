for i in range(99, 0, -1):
  print(i, "bottles of cola, take one down, pass it around.")