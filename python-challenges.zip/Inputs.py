myName = input('please enter your name.   ')
print('hello',myName)