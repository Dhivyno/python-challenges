age = int(input("What is your age?  "))
MHR = 0.7 * (225-age)
print("Your theoretical maximum heart rate is", MHR, "and you shoudlnt exceed", 0.75*MHR, "BPM when you exercise")