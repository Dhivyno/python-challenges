taylorSwiftbd = 1989
myBd = int(input('when were you born.'))
ageDifference = myBd - taylorSwiftbd 
print('taylor swift is', ageDifference, 'years older than you')


celebrityName = input('who is your favorite celebrity?  ')
celebrityBd = int(input('when was your favorite celebrity born.  '))
myBd = int(input('when were you born.  '))
ageDifference = myBd - celebrityBd 
print(celebrityName, 'is', ageDifference, 'years older than you')