coefficients = [1]
powers = []
var = 0
num = list(input("Enter your polynomial in the form (x+y)^n where n is an positive integer:  "))
def factorial(a):
  var = 1
  count = a
  for i in range(1, count+1):
    var = var*i
  a = var

n = int(num[6])
for i in range(1, n + 2):
  factorial(i)
  factorial(n-i)
  b = n/(i*n-i)
  n = int(num[6])
  coefficients[i] = b

for j in range(n + 1):
  print("Coefficient of x^",n-j,"y^",j,": ", coefficients[j] )