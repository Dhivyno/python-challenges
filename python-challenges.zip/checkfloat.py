check = input("Enter anything:  ")
try:
  a = float(check)
  print("Input is a float")
except:
  print("Not a float ")
