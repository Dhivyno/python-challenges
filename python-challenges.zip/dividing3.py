num = int(input("Enter a number:  "))
if num%3 == 0:
  print("your number is divisible by 3 and gives", num//3)
else:
  print("your number is not divisible by 3 and leaves a remainder of", num%3)