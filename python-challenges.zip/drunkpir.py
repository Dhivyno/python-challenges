import random
import turtle as t
while True:
  r = random.randint(0, 360)
  t.lt(r)
  t.fd(100)