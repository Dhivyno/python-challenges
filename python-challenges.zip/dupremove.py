list = [1, 8, 24, 5, 6, 1, 10, 16, 16, 7, 7, 8, 6]
a = [] 
for i in list: 
    if i not in a: 
        a.append(i) 
print(a)