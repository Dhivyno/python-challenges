mass = int(input("Mass: "))
radius = int(input("Radius: "))
escape = (2*(6.67*(10**-11))*mass/radius)**0.5