ratio = ((1+5**0.5)/2)

length = int(input("what is the length of your painting in metres?  "))
print("width should be", round(ratio*length, 3), "metres")