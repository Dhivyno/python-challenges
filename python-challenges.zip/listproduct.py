p = 1
a = [62, 90, 65, 8, 34, 9, 20]
print(sum(a))
for i in range(len(a)):
  p *= a[i]
print(p)