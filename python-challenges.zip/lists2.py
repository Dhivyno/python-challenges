nums = [1, 3, 3, 5, 1, 2, 6, 8, 43, 28]
print(sum(nums))
print(min(nums))
print(max(nums))
print(len(nums))
print(sum(nums)/len(nums))