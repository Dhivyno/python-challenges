list = ['a', 'b']
reverse = 