def make_it_laugh(string):
  string = string.replace("a", "haha")
  string = string.replace("e", "haha")
  string = string.replace("i", "haha")
  string = string.replace("o", "haha")
  string = string.replace("u", "haha")
  print(string)

make_it_laugh("hello world")