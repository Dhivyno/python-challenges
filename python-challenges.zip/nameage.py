name = input("What is you name?  ")
age = int(input("what is your age?  "))
print("Hello,", name)