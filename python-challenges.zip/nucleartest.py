phrase = "Those stewardesses did some johnny-jump-ups"

test = input("Type this : ")