n = 1
num = int(input("how high do you want your pyramid to be?  "))
for i in range(num):
  print("X"*n)
  n += 2