x=3.33333333
print(round(x,3))

print(round(x,1))

print(x)

#x is not changed and it is only rounded when printed
