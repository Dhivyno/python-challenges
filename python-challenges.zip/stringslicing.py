word = "minimize"

print(word[1:4])
print(word[-1:-5:-1])
print(word[1:6:2])