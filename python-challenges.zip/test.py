data = input("")
if len(data) != 0:
  print("data valid")