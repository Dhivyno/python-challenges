choice = int(input("which times table do you want?  "))
for i in range(1, 11):
  print(choice*i)