import turtle as t
t.shape("turtle")
j=input("What would you like me to write?")
t.write(j)
t.forward(100)
t.done()