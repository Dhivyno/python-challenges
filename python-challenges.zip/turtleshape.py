import turtle as t
t.color('red')
for i in range(8):
  t.fd(100)
  t.lt(360/8)
t.done()